﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirForceConsole.UI
{
    internal class UIIT
    {
        public static void MainPage()
        {
            //ConsoleUtility.Header();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;//Set fore color and display that the it portion is not implemented on console
            Console.WriteLine("###   ###         #  #                          ###                             #          \r\n #     #          ####                           #                              #          \r\n #     #          ####   ##   ###   #  #         #     ###         ###    ##   ###         \r\n #     #          #  #  # ##  #  #  #  #         #    ##           #  #  #  #   #          \r\n #     #          #  #  ##    #  #  #  #         #      ##         #  #  #  #   #          \r\n###    #          #  #   ##   #  #   ###        ###   ###          #  #   ##     ##        \r\n                                                                                           \r\n #                ##                             #             #               #     #    #     \r\n                   #                             #             #                     #    #     \r\n##    # #   ###    #     ##   # #    ##   ###   ###    ##    ###        #  #  ##    ###   ###   \r\n #    ####  #  #   #    # ##  ####  # ##  #  #   #    # ##  #  #        #  #   #     #    #  #  \r\n #    #  #  #  #   #    ##    #  #  ##    #  #   #    ##    #  #        ####   #     #    #  #  \r\n###   #  #  ###   ###    ##   #  #   ##   #  #    ##   ##    ###        ####  ###     ##  #  #  \r\n            #                                                                                   \r\n                                     ##                                                       #               \r\n                                      #                                                      # #              \r\n       ##    ##   ###    ###    ##    #     ##          ###    ##   ###   ###   #  #         #     ##   ###   \r\n      #     #  #  #  #  ##     #  #   #    # ##        ##     #  #  #  #  #  #  #  #        ###   #  #  #  #  \r\n      #     #  #  #  #    ##   #  #   #    ##            ##   #  #  #     #      # #         #    #  #  #     \r\n       ##    ##   #  #  ###     ##   ###    ##         ###     ##   #     #       #          #     ##   #     \r\n                                                                                 #                            \r\n       #    #                  #                                               #                            \r\n       #    #                                                                                               \r\n      ###   ###    ##         ##    ###    ##    ##   ###   # #    ##   ###   ##     ##   ###    ##    ##   \r\n       #    #  #  # ##         #    #  #  #     #  #  #  #  # #   # ##  #  #   #    # ##  #  #  #     # ##  \r\n       #    #  #  ##           #    #  #  #     #  #  #  #  # #   ##    #  #   #    ##    #  #  #     ##    \r\n        ##  #  #   ##         ###   #  #   ##    ##   #  #   #     ##   #  #  ###    ##   #  #   ##    ##   \r\n                                                                                                            \r\n");
        }
    }
}
